# KCC Media Portal: Developer Summary

How the Year 8 pages (Photography Unit and Western Genre Unit) are built, so a new page (for example Year 9) gets the same features: teacher edit mode, per-student saved work, PDF hand-in, interactive activities, and publishing through GitHub and Cloudflare.

**Reference implementations (the source of truth):** `photography.html` and `western.html`. The working files used to build them are not kept between chats, so these two finished files, plus this summary and `editor.js`, are what you give to a new chat.

---

## 1. Contents of this kit

| File | What it is |
|---|---|
| `DEVELOPER-SUMMARY.md` | This document. |
| `editor.js` | The teacher edit mode ("like Canva"), parameterised so each page has its own edits file and storage keys. Taken from `western.html`. |
| `editor.css` | The 30 CSS rules the editor needs. Paste into the page `<style>`. |
| `edits-starter.js` | A blank edits file to copy for a new page. |

---

## 2. The big picture

- **Static pages, no server, no database.** Each page is one self-contained `.html` file. Images are base64 in `window.IMG`. Everything a student does is saved in *their own browser* on *that computer*.
- **Hosting:** GitHub repo `mrhummerston/KCC-Media-Portal` (public) → Cloudflare Pages auto-deploys on every commit (about 1 minute). Site: `https://kcc-media-portal.pages.dev/`.
- **Folder:** all pages sit next to `film-trailers.html` (probably `public/`).
- **Portal cards:** `content.js` (`window.PORTAL.years["8"].assignments`) lists what each year group sees. A card is `{ title, text, url, image }`. Add `"9": { page:"", assignments:[...], resources:[...] }` for Year 9.

```
public/
  index.html (portal)   content.js   film-trailers.html
  photography.html      edits.js              <- window.PHOTO_EDITS
  western.html          western-edits.js      <- window.WESTERN_EDITS
  western-media/        (mp4 clips)
  folio-task-sheet.docx / .pdf
  year9-xxx.html        year9-xxx-edits.js    <- window.YEAR9XXX_EDITS   (new)
```

**What a teacher cannot see:** student work. It never leaves the student's browser. The hand-in is the PDF the student saves.

---

## 3. Checklist: creating a Year 9 page

1. **Pick a base.**
   - Lesson-style unit with notes, writing, checklists, PDF: copy `western.html`. It has the cleanest engine (blocks) and the parameterised editor.
   - Photo folio (drag-and-drop photos, labels, interactive PDF): start from `photography.html`.
2. **Choose unique names** (never reuse another page's keys, or the pages will overwrite each other's data):

   | Thing | Example for a Year 9 "Documentary" page |
   |---|---|
   | Page file | `year9-documentary.html` |
   | Edits file | `year9-documentary-edits.js` |
   | Edits variable | `window.Y9DOC_EDITS` |
   | Progress key | `kcc-y9doc-v1:` + student id |
   | Editor flags | `kcc-teacher-y9doc`, `kcc-editing-y9doc` |
   | Draft key | `kcc-y9doc-edits-draft` |
   | IndexedDB name (if photos) | `kcc-y9doc-photos-` + student id |
3. **Keep the shared student identity key** `kcc-photo-student` (`{first,last,id}`) so students type their name once across all pages.
4. **Replace content only:** `CONCEPTS` (lessons), `HOME` (grouping), `window.IMG` (pictures). Leave the engine alone.
5. **Wire the editor** (section 6).
6. **Add the portal card** in `content.js` (section 2).
7. **Run the tests** (section 11), then upload to GitHub.

---

## 4. Student identity and saving

- **Name gate:** a dialog (`#nameDlg`) asks first and last name once. Stored in `localStorage['kcc-photo-student']` as `{first, last, id}`. "Not you?" button clears it.
- **Student id:** `makeId(first,last)` = readable slug + 6-char hash of the lowercased, space-normalised name, e.g. `sam-lee-104lud`. Same name typed again gives the same id, so work comes back.
- **Progress** is one JSON object in `localStorage`, saved by `persist()` after every change.

| Page | Progress key | Shape |
|---|---|---|
| Photography | `kcc-photo-v2:<id>` | `{fill, done, quiz, cam, folio:{coverCount, meta}, pdfAt, visits, firstSeen}` |
| Western | `kcc-west-v1:<id>` | `{done, f, chk, sort, match, list, trope, ideas, track, visits}` |

- **Photos** go in IndexedDB `kcc-photo-folio-<id>`, version 1, object store `photos`. Keys: `<slotId>` = resized copy (long side 1600, JPEG 0.88); `<slotId>:orig` = the student's original file. Old saves have no `:orig` key; the code falls back to the copy.
- **Adding a field to saved data safely:** in `loadProgress()` always merge with a default (`fill: p.fill || base.fill`). Never rename or delete existing keys, or students' work is orphaned.
- **Updating a page file does not touch student data** (it lives in their browser). It was tested by loading an old-format save into the new page.
- **What loses work:** clearing browser data, a school profile wipe at logout, a different computer or browser, typing a different name, or the "Start a new folio" button. Tell students to save a PDF every week.

---

## 5. Page structure (lesson engine)

**Routes** (hash): `#unit` (home), `#unit/<lessonId>`, and `#folio` (photography only). `route()` is a global; the editor calls it.

**Home page:** `HOME = [{h:'Week 1', ids:[...]}, ...]` renders tiles. Each tile is a lesson with `id, week, icon, color, title, short`.

**Western `CONCEPTS` lesson** = `{ id, week, icon, color, title, short, idea, blocks:[...] }`. Each block is `{t:'type', ...}` and is rendered by `BLK.<type>(b)` and made interactive by `WIRE.<type>(box, b)`.

Block types available in `western.html`:

| Block | Use |
|---|---|
| `text`, `steps`, `tipbox`, `cards`, `gallery`, `video`, `banner`, `rules`, `about`, `scenes` | Static content |
| `check` | Tick list that saves, optional pictures per item |
| `form` | Labelled boxes that save as you type |
| `sorter` | Tap or drag cards into buckets |
| `matcher` | Pick the right label from a menu per item |
| `tropes`, `ideabank`, `adder`, `elements` | Chart of ticks, tick bank, list adder with timer, worksheet |
| `swatnotes`, `rangonotes`, `resp` | Notes tables and the tracked response writer (section 9) |
| `storyboard`, `storyplan`, `preprod`, `markkey` | Storyboard frames, planner, pre-production sheet, marking key |
| `clickview` | Link button plus iframe (ClickView may refuse to show inside another site) |
| `pdf` | "Save to PDF" button |

**Photography `CONCEPTS` lesson** uses a `layout:[...]` array of part names. Parts: `visual, hero, hero2, trio, compare, video, galleries, quiz, steps, steps2, stepsTip, lcd, skill, techs, findit, cards, interactive, guided, dialpair, second, levels, bonus`. `levels` (see the Light Painting Challenge) draws one panel per difficulty level: `{stars, color, h, items[], photos[] | diagram}` with a coloured side bar, a star rating and the photos below the steps. Add your own by adding a part function in `showLesson` and a lesson field.

**Adding a block type (Western pattern):**
```js
BLK.mytype = function(b){ return panel('mytype', head(b) + '...html...', {noedit:true, id:b.id}); };
WIRE.mytype = function(box, b){ /* attach events, read/write S */ };
```
Use `{noedit:true}` for anything with inputs (see section 6).

---

## 6. Teacher edit mode ("like Canva")

**Gate:** footer link `#teachLink` ("Teacher") → password prompt → toolbar `#edBar` appears. Password is the `PASSWORD` constant at the top of `editor.js`. Flags live in `sessionStorage` (`FLAG` = teacher, `EDIT_FLAG` = currently editing). Students never see any editor UI.

**Security:** the password check is in browser code, so it is **not real security**. A determined student could open edit mode in their own browser, but their edits only exist in their own browser. **Nothing can be published without GitHub write access**, which only the teacher has. That is the real lock.

**What the teacher can do:**
- Retype any text; font family (11 options), size, colour, bold/italic/underline, alignment; whole-page text size.
- Move blocks (drag or ◀ Earlier / Later ▶), set width (auto / half / full), set column count, hide or delete, undo / redo, "undo all on this page", select parent.
- Pictures: resize (+/−, drag), align, crop and zoom, flip, replace, add new ones by **dragging picture files onto the page** (resized to 900 px wide JPEG 0.82 and embedded as data URLs).
- Add new text blocks and picture blocks.
- **Add lesson templates in one click** (row "Add to this lesson"): objective box ("Learning Intent: By the end of this lesson, students will be able to..."), vocabulary card (keyword | definition side by side), discussion prompt (blockquote), text box, Heading 1, Heading 2, rectangle, circle, picture. Each is stored as an added block `{id, type:'panel', cls:'ed-tpl ed-tpl-<name>', html}` and styled by `.panel.ed-tpl-*` CSS in `editor.css`. Shapes and the text box start with a size (`bw`, `bh`).
- **Resize any box** with the square corner handle (width and minimum height saved as `bw` and `bh`; pictures keep their own `w`). Fixed widths also get `max-width:100%` so phones never scroll sideways.
- **Fill, border colour, border width and opacity** for any selected box (`bg`, `bd`, `bdw`, `op` in the block record; "No fill" remembers the previous fill in `bgp`).
- **Fonts:** 17 options, including Inter, Open Sans, Roboto, Lexend, Comic Sans, Comic Neue and Playfair Display. The page must load them (Google Fonts link in `<head>`).
- **Present** hides the top bar, footer, navigation and toolbars so only the lesson shows (full screen where allowed, Esc to leave). **Clear added items** removes everything added to the current page (confirm, then Undo works). **Download lesson (.html)** saves the current page as a stand-alone file (pictures embedded, editing marks removed; activities are inert).
- **Free move:** select any text or box, drag the purple **✥ Free** handle (it says *text* or *box*) to place it anywhere. **↺ Reset position** puts it back. Undo / redo work. Select parent first to move a whole box instead of one heading.

**What it does NOT do:** save straight to GitHub. A live GitHub save with a personal access token was designed but **declined** by the teacher; edits are published by uploading the edits file.

**How free move is stored:** a CSS transform. Text elements keep it in `E.style[key].tr` (`STYLE_PROPS.tr = 'transform'`); blocks keep it in `E.block[key].tr`. Elements that are both a block and text (such as step list items) use the text record, so the two never clash. Moved elements get `data-kfree`; `[data-kfree]{position:relative;z-index:5}` and `@media (max-width:700px){[data-kfree]{transform:none!important}}` mean **phones ignore free positions** and keep the normal layout, so nothing can be pushed off-screen. Nothing needs changing when you build a new page except including `editor.css`.

**Using it well:** the toolbar is fixed across the bottom of the screen (about 275 px tall), so scroll the thing you want to edit up into the top half first, or its handles end up hidden behind the toolbar.

**How edits are saved and published:**
1. Edits are kept as a list in memory, auto-saved to a **draft** in the teacher's `localStorage` (`DRAFT_KEY`).
2. **Save my changes** downloads the edits file (for example `edits.js`).
3. Teacher uploads that file to GitHub next to the page, replacing the old one. Cloudflare redeploys in about a minute.
4. On every page load, `<script src="...edits.js">` defines `window.<EDITS_VAR>`, and the editor applies it on top of the page for **everyone**.

**Edits file schema (v1):**
```js
window.PAGE_EDITS = {"v":1,"text":{},"style":{},"block":{},"order":{},"hide":{},"cols":{},"add":{},"global":{}};
```
`text` = retyped text, `style` = per-element font/size/colour/etc., `block` = width/crop/size/picture/position (`tr`)/box size (`bw`,`bh`)/fill (`bg`)/border (`bd`,`bdw`)/opacity (`op`) per block, `order` = reordered children, `hide` = deleted/hidden, `cols` = column counts, `add` = new blocks, `global` = page-wide font/scale. Keys are per view (home, each lesson) plus a stable key derived from the element (see `blockBase`, `usedKeys`, `slug` in `editor.js`).

**Wiring a page to the editor (exact order matters):**
```html
<!-- footer -->
<a href="#" id="teachLink">Teacher</a>

<!-- end of body -->
<script src="year9-xxx-edits.js"></script>   <!-- 1. defines window.Y9XXX_EDITS -->
<script>window.KCC_EDIT_CFG = {editsVar:'Y9XXX_EDITS', draft:'kcc-y9xxx-edits-draft',
  flag:'kcc-teacher-y9xxx', editFlag:'kcc-editing-y9xxx', file:'year9-xxx-edits.js', noFolio:true};</script>
<script> /* paste editor.js here */ </script>
<script> /* the page code */ </script>
```
In the page code:
```js
if (window.KCCEdit) KCCEdit.after('home', homeEl);              // after drawing the home page
if (window.KCCEdit) KCCEdit.after('lesson:' + id, lessonEl);    // after drawing each lesson
if (window.KCCEdit) KCCEdit.ready();                            // once, at the very end
// if no student is set and the teacher is logged in, make a preview profile:
if ((!student || !student.id) && window.KCCEdit && KCCEdit.isTeacher()) student = {first:'Teacher', last:'Preview', id:'teacher-preview-y9xxx'};
```
The page must expose a global `route()` and a global `CONCEPTS` (the editor uses them for the page picker and refreshing). Set `noFolio:true` unless the page has a `#folio` view. Photography calls `KCCEdit.after('folio', el, {blocks:false})`.

**Rules for editable vs protected areas:**
- Editor selectors: text = `h1,h2,h3,p,li,figcaption,td,summary,.badge`; blocks = `.panel,.fig,.tile,.tip,.idea,.visual,.head, ol.steps>li, ...` (see `TEXT_SEL`, `BLOCK_SEL`).
- Anything inside `[data-noedit]` (and the `SKIP` list: `.qcard, .slot, .fields, dialog, .topbar, .foot, .opts` etc.) is skipped. **Put `data-noedit` on every interactive area** (inputs, games, tables the student fills in) so the teacher cannot break them. Headings and text outside those areas stay editable.
- Editor CSS (`editor.css`) must be in the page. Classes: `.ed-editing`, `.ed-sel`, `#edBar`, `[data-kt]` (text), `[data-kb]` (block), `[data-kc]` (container).

---

## 7. Interactive components you can reuse

| Component | Where | How it works |
|---|---|---|
| Mode dial widget | photography | SVG dial, 8 positions, 45° per click. State `S.cam.k` for the Know-your-camera one, or `S.cam.dk[key]` per lesson. Config `{widget:'dial', target:'Av', key:'aperture'}`. |
| Lens AF/MF switch | photography | SVG of the side of a Canon lens, switch slides 30 units. State `S.cam.mf`. |
| "Circle it" games | photography | Camera photo (`CAMERA.targets`) and drawn LCD screen (`LCD.cfg/spots/decoys`). Student draws a circle; `judgeRing(pts, target, others, lim)` accepts it if it is closed, not too big, covers ≥75% of the target, and is centred on the right part when neighbours are inside. Tuned with a Monte-Carlo simulation: power switch accepted 99.8%, wrong parts 0%. |
| Quiz with reset | photography | `QUIZ[kind]` = `{title, pre, unit, ph, ref[[img,label]], refCap, options, stops, stopsL, photos[{img, ans, show, hint}], carousel?}`. 3 photos, hints after tries, "Show me", **reset button after all 3 correct** (re-renders `quizSectionHTML`). |
| Photo carousel | photography | `QUIZ.iso.carousel = true` → one photo at a time with ◀ ▶, keys, swipe, jump buttons. |
| Fill-in-the-gaps rule | photography ISO | Inputs `data-fill`, accepted-word lists in `RULE_OK`, Check / Try again, saved in `S.fill`. |
| YouTube Short | photography | `videoHTML({id, h, cap})` uses `youtube-nocookie.com/embed/<id>` in a 9:16 frame plus an "Open on YouTube" fallback. |
| Sorter, matcher, tick charts | western | Section 5 table. |
| Task-sheet viewer | photography folio | Card with thumbnail; click opens a dialog with the document (HTML), A−/A+, Word and PDF downloads. |

---

## 8. Photo folio module (photography.html)

- **Structure:** `FOLIO` = sections (`cover`, `p1`..`p6`), each with `slots:[{id, name, label, choices?, value?, cap?}]`. Labels: `labelParts(id)`; missing-label check: `missing(id)`.
- **Adding photos:** drag-and-drop or tap; `addFiles` fills the next empty slots; `setPhoto` stores the resized copy **and the original file** (`id:orig`). If storage fails it falls back gracefully.
- **Viewer:** click a photo → `#phDlg` full-screen. Shows the original (decoded in the background, the saved copy shows first), ◀ ▶ and arrow keys across all photos in folio order, swipe, **See at 100%** with drag-to-pan for checking focus, caption, size info.
- **EXIF orientation:** `createImageBitmap(file, {imageOrientation:'from-image'})` so sideways camera photos show upright.
- **PDF (`makePdf`)**: **jsPDF 2.5.2** inlined as `<script id="jspdf-lib">` (no network). A4 landscape; cover, six folio pages, then one full-size page per photo. Every thumbnail is a link to its full-size page; full-size pages have Back / Previous / Next links; PDF bookmarks. Each photo is embedded **once**. File name `First, Last, Photography Folio.pdf`.
- **Size budget:** `PDF_TARGET_MB = 20`. Each photo gets its share of the remaining budget and steps down `PDF_TIERS` (3000 px / 0.88 down to 1800 px / 0.72) only if needed. Test results: 25 grainy camera photos (169 MB) → 18.7 MB; 8 photos → 10 MB at full 3000 px. Sharp and blurry photos stay clearly different. Old photos with no original are embedded as their saved copy.
- **Text limits in the PDF:** jsPDF's built-in fonts cover Latin-1 only; `winAnsi()` simplifies other characters (for example ā → a).
- **Fallback:** if jsPDF fails, the dialog offers the browser print window (`doPrint`, print CSS).

---

## 9. Assessed writing with a process report (western.html)

Used for the Rango notes and response. Pattern to reuse for any task where AI use is a concern.

- **Paste, drop and bulk insertion are blocked** in fields marked `data-assess`. Typed text is tracked with a *provenance string* per field (`T` = typed, `X` = arrived another way). Edits to saved text outside the box are counted as `X`.
- **Recorded:** paste/drop attempts, characters typed vs not, typing speed and fastest 10-second burst, characters deleted, active minutes, time away from the page, and similarity to the class resources (share of words in matching 5-word phrases from the lesson text).
- **Flags** (not scores): paste attempted, >3% not typed, burst >110 words per minute, 400+ characters with almost no corrections, >10 minutes away, >25% similarity.
- **PDF:** `printDoc('response')` builds a clean document (response, notes table, process report at the bottom) and uses `window.print()` with the document title set to `First, Last, Rango Response`.
- **It is not an AI detector** and says so on the report. A real AI/plagiarism percentage was considered and **declined** (unreliable, risks false accusations). Pasting is blocked but retyping from another screen cannot be.

---

## 10. Design system and accessibility

- **Fonts:** Atkinson Hyperlegible (body), Bricolage Grotesque (headings), Rye (Western title only). Google Fonts, with system fallbacks.
- **Tokens (`:root`, with `:root[data-theme="dark"]` overrides):** `--bg --surface --surface2 --text --muted --line --accent --accent-hover --on-accent --focus --ok --warn --bad --display --body`. Theme stored in `localStorage['kcc-theme']`, set before first paint to avoid a flash.
- **Rules followed:** touch targets at least 44 px; visible focus rings; `aria-live` on feedback; every picture has alt text; no sideways scroll at 390 px; dialogs use `<dialog>`; colour is never the only signal (ticks and text too).
- **Mobile:** every lesson was checked at 390 px width for overflow. Long Previous/Next buttons wrap.

---

## 11. Build, patch and test workflow

**No build tool is required.** The original build was a Python script that filled placeholders (`/*__IMAGES__*/`, `/*__EDITOR__*/`) in a template. Because those files are not kept, the practical workflow now is:

1. Keep backups (`cp page.html page_before.html`).
2. Patch the finished HTML with a small Python script that does `str.replace` and **asserts each search string occurs exactly once** (it fails loudly instead of editing the wrong place).
3. Syntax-check every script: extract the `<script>` blocks and run `node --check`.
4. Keep the page JavaScript ES5-style (`var`, `function`, Promises) so it runs on older school browsers. The page code does not use `async/await` or `let`/arrow functions (the test scripts do, which is fine).

**Testing recipe:**
- **Logic (Node + jsdom):** boot the page with `runScripts:'dangerously'`, stub `matchMedia`, `showModal`, `fetch`, seed `localStorage`, drive it with `hashchange` and DOM events. jsdom has **no IndexedDB, no `createObjectURL`, no layout**.
- **Real browser (headless Chrome):** `npm i @sparticuz/chromium puppeteer-core`. Needed for photos, IndexedDB, viewer, PDF download (`Browser.setDownloadBehavior`), layout screenshots and the 390 px overflow check. Always `browser.close()` or kill leftover `headless_shell` processes (they slow everything else).
- **PDF checks:** `pypdf` (pages, bookmarks, links, embedded images) and `pypdfium2` (render pages to PNG).
- **Randomised testing** for judgement code (the circle game): generate thousands of wobbly human-style circles and measure acceptance.
- **Always test:** every lesson opens with no script errors; saved data survives leaving and returning; old-format saves still load; teacher mode can edit text but not the interactive areas; phone width.

---

## 12. Gotchas learned the hard way

- `dialog{max-width:560px}` in the base CSS shrinks any big dialog. Override with `dialog.mine{max-width:...}`.
- `.panel.wide` spans all columns of `.lgrid`. Inside a two-column grid add `.pairgrid>.panel{grid-column:auto!important}`.
- Tab highlight needs `aria-current="page"`, not just the attribute present (`toggleAttribute` sets an empty value).
- Document-level listeners added when a lesson draws will leak and throw after you leave it. Use `onDoc(box, type, fn)` which removes itself when the box is gone.
- `loading="lazy"` on inline base64 images causes blank gaps and layout jumps. Leave it off.
- Chrome does not repeat `position:fixed` elements or a single-row table footer on every printed page. Do not rely on that for per-page footers.
- Printing: build a hidden `#printDoc` and add `body.printing`; hide everything else with print CSS. Set `document.title` for the file name; restore it in `onafterprint`.
- A `.btn` is full width by default; inside a centred paragraph add `display:inline-flex;width:auto`.
- The LCD circle game must be checked statistically, not by hand; small targets need a bigger size limit (`max(110, 7×radius)`).
- YouTube, ClickView and SharePoint may block embedding inside another site or need a login. Always provide a plain "open in new tab" button next to an embed.
- Two Word files from the teacher were unusable: one was all zero bytes (upload error) and one conversion produced blank pages. Check the input first (`file`, byte counts).
- Any element given a fixed pixel width by the teacher needs `max-width:100%`, or a phone gets a sideways scroll bar (this happened with resized shapes).
- A global rule `.visual svg{max-height:240px}` squashes diagrams. A big diagram needs `.myclass svg{max-height:none}`.
- Testing tip: never put `pkill -f <name>` inside a shell command that also contains `<name>`: it kills its own shell. Close browsers from inside the test script instead.
- Fonts and other web resources fail to load in the sandbox (no internet). Console errors about `ERR_NAME_NOT_RESOLVED` there are harmless.

---

## 13. Decisions, limits and open items

**Declined or not built:**
- Live "Publish to GitHub" from edit mode (token approach). Edits are published by uploading the edits file.
- AI-use or plagiarism percentage. A process report is used instead.

**Open:**
- Portal main page changes still waiting for the portal's own HTML: relabel the Photography card "Assignments" → "Unit", and remove "Coming soon" from Resources.
- `1__Western_Genre_-_Year_8_Media_Intro.docx` was an empty file; ask for a re-upload.
- Western film clips and stills are the film studio's property. Fine inside the school, but the repo is public. Consider making it private.
- The `G and PG` trailers link is a school SharePoint folder (needs a school login).
- HEIC photos are not supported by most browsers.

**Hand-in model:** students hand in a PDF (folio, response). Nothing is collected automatically.

---

## 14. Prompt to start a new page in a fresh chat

> I'm a media teacher at Kingsway Christian College. I'm attaching `DEVELOPER-SUMMARY.md`, `editor.js`, `editor.css`, `edits-starter.js`, and my two finished pages `western.html` and `photography.html`.
>
> Please build **`year9-<topic>.html`** with the same architecture:
> - single self-contained file, images embedded, works with no server;
> - name gate shared with the other pages (`kcc-photo-student`), progress saved per student in the browser under the new unique keys `kcc-y9<topic>-v1:`;
> - lesson tiles on a home page and lessons built from blocks, in my wording where I give it;
> - **teacher edit mode** exactly as in the summary (own edits file `year9-<topic>-edits.js`, `window.KCC_EDIT_CFG`, `data-noedit` on interactive areas);
> - [portfolio with photos, original files kept, click-to-enlarge viewer and a ~20 MB interactive PDF] **or** [tracked writing task with a process report];
> - Save to PDF named "First, Last, <Task>";
> - dark mode, 44 px touch targets, no sideways scroll at 390 px.
>
> Also give me the `content.js` card for Year 9 and a short publishing checklist. Test it (jsdom for logic and headless Chrome for layout/PDF) and show me screenshots. Do not rename any storage key used by the Year 8 pages.
>
> The unit is: *[topic, weeks, lessons, assessment task, what students must hand in, resources I'm attaching]*.

---

## Appendix A: minimal page skeleton

```html
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Year 9 ... | KCC Media Portal</title>
<script>/* set data-theme from localStorage['kcc-theme'] or prefers-color-scheme BEFORE paint */</script>
<style>/* tokens, base styles, editor.css */</style></head>
<body>
<header class="topbar noprint">… links, #saved, #who, #switchBtn, #themeBtn …</header>
<main id="main" class="wrap"><section id="viewHome" hidden></section><section id="viewLesson" hidden></section></main>
<footer class="foot noprint"><a href="#" id="teachLink">Teacher</a></footer>
<dialog id="nameDlg">…first and last name form…</dialog>
<script>window.IMG = { /* key: "data:image/jpeg;base64,..." */ };</script>
<script src="year9-xxx-edits.js"></script>
<script>window.KCC_EDIT_CFG = { … };</script>
<script>/* editor.js */</script>
<script>/* page code: helpers, student gate, persist(), CONCEPTS/HOME, BLK/WIRE, route() */</script>
</body></html>
```

## Appendix B: the persist pattern

```js
function loadProgress(){ var p = lsGet(KEY + student.id, null) || {}, b = newProgress();
  S = { done: p.done || b.done, f: p.f || b.f /* every new field gets a default here */ }; }
function persist(){ if (!student) return; if (!lsSet(KEY + student.id, S)) showStorageWarn(); flashSaved(); }
```

## Appendix C: the paste-block pattern

```js
el.addEventListener('paste', function(e){ e.preventDefault(); count(e.clipboardData.getData('text').length); });
el.addEventListener('drop',  function(e){ e.preventDefault(); count(0); });
el.addEventListener('beforeinput', function(e){ if (/^insertFrom(Paste|Drop|Yank)/.test(e.inputType)) e.preventDefault(); });
// on 'input': diff old vs new value; mark inserted characters 'T' if inputType is typing and <= 20 chars, else 'X'
```
