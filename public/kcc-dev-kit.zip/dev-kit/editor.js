/* =====================================================================
   VISUAL EDITOR (teacher edit mode)
   - Students never see any of this. It only switches on after the teacher
     enters the password via the footer link.
   - Everything you change is kept as a list of small "edits" and saved to
     edits.js, which sits next to photography.html and is applied on top of
     the page every time it loads.
   ===================================================================== */
(function () {
  'use strict';
  var CFG = window.KCC_EDIT_CFG || {};
  var DRAFT_KEY = CFG.draft || 'kcc-photo-edits-draft', FLAG = CFG.flag || 'kcc-teacher', EDIT_FLAG = CFG.editFlag || 'kcc-editing', PASSWORD = 'Media123', EDITS_VAR = CFG.editsVar || 'PHOTO_EDITS', EDITS_FILE = CFG.file || 'edits.js';
  var TEXT_SEL = 'h1,h2,h3,p,li,figcaption,td,summary,.badge';
  var BLOCK_SEL = '.panel,.fig,.tile,.tip,.folio-box,.idea,.visual,.head,ol.steps>li,ul.plain>li,ul.chips>li,ul.stops>li,ul.triangle>li,ul.checks>li';
  var SKIP = '.qcard,.slot,.fields,dialog,.topbar,.foot,#edBar,#edOv,#edPrev,.printdoc,.print-title,.print-label,.run-head,.print-empty,.fb,.qsum,.state,.err,.busy,.back,.opts,[data-noedit]';
  var FONTS = [['Page default', ''], ['Atkinson Hyperlegible', '"Atkinson Hyperlegible","Segoe UI",sans-serif'], ['Bricolage Grotesque', '"Bricolage Grotesque","Segoe UI",sans-serif'],
    ['Segoe UI', '"Segoe UI",system-ui,sans-serif'], ['Arial', 'Arial,Helvetica,sans-serif'], ['Verdana', 'Verdana,Geneva,sans-serif'], ['Trebuchet MS', '"Trebuchet MS",sans-serif'],
    ['Georgia', 'Georgia,serif'], ['Times New Roman', '"Times New Roman",Times,serif'], ['Courier New', '"Courier New",monospace'], ['Comic Sans MS', '"Comic Sans MS","Comic Sans",cursive'],
    ['Inter', '"Inter",system-ui,sans-serif'], ['Open Sans', '"Open Sans",system-ui,sans-serif'], ['Roboto', '"Roboto",system-ui,sans-serif'], ['Lexend (easy to read)', '"Lexend",system-ui,sans-serif'],
    ['Comic Neue (Comic Sans style)', '"Comic Neue","Comic Sans MS",cursive'], ['Playfair Display (serif)', '"Playfair Display",Georgia,serif']];

  function q(s, r) { return (r || document).querySelector(s); }
  function qa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function blank() { return { v: 1, text: {}, style: {}, block: {}, order: {}, hide: {}, cols: {}, add: {}, global: {} }; }
  function norm(e) { var b = blank(); if (e && typeof e === 'object') Object.keys(b).forEach(function (k) { if (e[k] !== undefined && e[k] !== null) b[k] = e[k]; }); return b; }
  function copy(e) { return norm(JSON.parse(JSON.stringify(e))); }
  function snap(e) { var o = {}; Object.keys(e).forEach(function (k) { o[k] = (e[k] && typeof e[k] === 'object') ? Object.assign({}, e[k]) : e[k]; }); return o; }
  function nf(s) { return String(s || '').replace(/["'\s]/g, '').toLowerCase(); }
  function fontVal(v) { for (var i = 0; i < FONTS.length; i++) if (nf(FONTS[i][1]) === nf(v)) return FONTS[i][1]; return ''; }
  function slug(s) { return String(s || '').toLowerCase().replace(/<[^>]*>/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 36); }

  var pub = norm(window[EDITS_VAR]);
  var teacher = false, editing = false;
  try { teacher = sessionStorage.getItem(FLAG) === '1'; editing = teacher && sessionStorage.getItem(EDIT_FLAG) === '1'; } catch (e) {}
  var E = pub;
  if (teacher) {
    try { var dr = localStorage.getItem(DRAFT_KEY); E = dr ? norm(JSON.parse(dr)) : copy(pub); } catch (e) { E = copy(pub); }
  }
  var cropMode = false;
  var hist = [snap(E)], redo = [], sel = null, curView = null, curRoot = null, dragEl = null, draftWarned = false;

  /* ---------- safe HTML ---------- */
  function clean(html) {
    var t = document.createElement('template'); t.innerHTML = String(html || '');
    qa('script,iframe,object,embed,style,link,meta,form,input,textarea,select,button', t.content).forEach(function (n) { n.remove(); });
    qa('*', t.content).forEach(function (n) {
      Array.prototype.slice.call(n.attributes).forEach(function (a) {
        var nm = a.name.toLowerCase();
        if (nm.slice(0, 2) === 'on' || ((nm === 'href' || nm === 'src') && /^\s*javascript:/i.test(a.value))) n.removeAttribute(a.name);
      });
    });
    return t.innerHTML;
  }

  /* ---------- whole-page font and size ---------- */
  function applyGlobal() {
    var g = E.global || {}, st = document.documentElement.style;
    function fam(v, fallback) { return v ? v + ',' + fallback : ''; }
    if (g.body) st.setProperty('--body', g.body); else st.removeProperty('--body');
    if (g.display) st.setProperty('--display', g.display); else st.removeProperty('--display');
    st.fontSize = g.scale && g.scale !== 100 ? g.scale + '%' : '';
  }
  applyGlobal();

  /* ---------- naming every piece so edits can find it again ---------- */
  function blockBase(el) {
    var im = el.matches('.fig') ? el.querySelector('img[data-img]') : null;
    if (im) return 'fig:' + im.getAttribute('data-img');
    if (el.matches('.tile')) return 'tile:' + (el.getAttribute('href') || '').replace('#unit/', '');
    var h = el.querySelector('h1,h2,h3');
    if (el.matches('.panel')) return 'panel:' + slug((h && h.textContent) || el.textContent.slice(0, 30));
    return el.tagName.toLowerCase() + ':' + slug(el.textContent.slice(0, 40));
  }
  function usedKeys() {
    var u = {};
    qa('[data-kb],[data-kt],[data-kc]').forEach(function (n) { ['data-kb', 'data-kt', 'data-kc'].forEach(function (a) { var v = n.getAttribute(a); if (v) u[v] = 1; }); });
    return u;
  }
  function tagAll(root, vk, blocks) {
    var u = usedKeys();
    function mk(base) { var k = base, n = 1; while (u[k]) { n++; k = base + '~' + n; } u[k] = 1; return k; }
    if (blocks) {
      qa(BLOCK_SEL, root).forEach(function (el) {
        if (el.hasAttribute('data-kb') || el.closest(SKIP)) return;
        el.setAttribute('data-kb', mk(vk + '|b|' + blockBase(el)));
      });
      qa('[data-kb]', root).forEach(function (el) {
        var p = el.parentElement; if (!p || p.hasAttribute('data-kc')) return;
        var anc = p.closest('[data-kb]');
        p.setAttribute('data-kc', mk(vk + '|c|' + (p.id || (p.className && String(p.className).split(' ')[0]) || p.tagName.toLowerCase()) + '|' + (anc ? anc.getAttribute('data-kb') : '-')));
      });
    }
    qa(TEXT_SEL, root).forEach(function (el) {
      if (el.hasAttribute('data-kt') || el.closest(SKIP) || el.closest('[data-added]')) return;
      if (!el.textContent.trim() || el.querySelector(TEXT_SEL)) return;
      el.setAttribute('data-kt', mk(vk + '|t|' + el.tagName.toLowerCase() + ':' + slug(el.textContent)));
      el.__orig = el.innerHTML;
    });
  }

  /* ---------- putting the edits onto the page ---------- */
  var STYLE_PROPS = { ff: 'fontFamily', fs: 'fontSize', c: 'color', fw: 'fontWeight', fi: 'fontStyle', td: 'textDecoration', ta: 'textAlign', tr: 'transform' };
  function setTextStyle(el, s) { Object.keys(STYLE_PROPS).forEach(function (k) { el.style[STYLE_PROPS[k]] = (s && s[k]) || ''; }); }
  function readTextStyle(el) { var o = {}; Object.keys(STYLE_PROPS).forEach(function (k) { var v = el.style[STYLE_PROPS[k]]; if (v) o[k] = v; }); return o; }
  var CROP0 = { ar: 'orig', z: 1, px: 50, py: 50, flip: 0 };
  function figTarget(el) {
    if (!el || !el.matches) return null;
    if (el.matches('.fig')) return el;
    return el.getAttribute('data-added') === 'pic' ? q('.fig', el) : null;
  }
  function layoutCrop(wrap, im, c) {
    var ir = (im.naturalWidth || 4) / (im.naturalHeight || 3), fr = ir;
    if (c.ar && c.ar !== 'orig') { var p = String(c.ar).split('/'); fr = (+p[0]) / (+p[1]) || ir; }
    var z = Math.max(1, c.z || 1), wi, hi;
    if (ir >= fr) { hi = z * 100; wi = z * 100 * ir / fr; } else { wi = z * 100; hi = z * 100 * fr / ir; }
    wrap.style.aspectRatio = String(fr);
    im.style.width = wi + '%'; im.style.height = hi + '%';
    im.style.left = (-(wi - 100) * (c.px == null ? 50 : c.px) / 100) + '%';
    im.style.top = (-(hi - 100) * (c.py == null ? 50 : c.py) / 100) + '%';
    im.style.transform = c.flip ? 'scaleX(-1)' : '';
  }
  function applyCrop(fg, c) {
    var im = q('img', fg); if (!im) return;
    var wrap = im.parentElement && im.parentElement.classList.contains('ed-crop') ? im.parentElement : null;
    if (!c) { if (wrap) { wrap.parentElement.insertBefore(im, wrap); wrap.remove(); im.removeAttribute('style'); } return; }
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'ed-crop'; im.parentElement.insertBefore(wrap, im); wrap.appendChild(im); }
    layoutCrop(wrap, im, c);
    if (!im.naturalWidth) im.addEventListener('load', function () { layoutCrop(wrap, im, c); }, { once: true });
  }
  function applyBlock(el, b) {
    b = b || {};
    if (!el.hasAttribute('data-kt')) { if (b.tr) { el.style.transform = b.tr; el.setAttribute('data-kfree', '1'); } else if (el.hasAttribute('data-kfree')) { el.style.transform = ''; el.removeAttribute('data-kfree'); } }
    el.style.gridColumn = b.span ? (b.span === 'full' ? '1 / -1' : 'span ' + b.span) : '';
    var nf = !figTarget(el);
    if (b.bg !== undefined) el.style.background = b.bg; else el.style.removeProperty('background');
    if (b.bdw !== undefined || b.bd) { var bw0 = b.bdw === undefined ? 2 : b.bdw; el.style.borderStyle = bw0 ? 'solid' : 'none'; el.style.borderWidth = bw0 ? bw0 + 'px' : ''; if (b.bd) el.style.borderColor = b.bd; }
    else { el.style.removeProperty('border-style'); el.style.removeProperty('border-width'); el.style.removeProperty('border-color'); }
    if (b.op !== undefined) el.style.opacity = b.op; else el.style.removeProperty('opacity');
    if (nf && b.bw) { el.style.width = b.bw + 'px'; el.style.maxWidth = '100%'; } else if (nf) { el.style.removeProperty('width'); el.style.removeProperty('max-width'); }
    if (nf && b.bh) el.style.minHeight = b.bh + 'px'; else if (nf) el.style.removeProperty('min-height');
    var fg = figTarget(el);
    if (fg) {
      fg.style.width = b.w ? b.w + 'px' : ''; fg.style.maxWidth = b.w ? '100%' : '';
      fg.style.marginLeft = b.align === 'center' || b.align === 'right' ? 'auto' : (b.align === 'left' ? '0' : '');
      fg.style.marginRight = b.align === 'center' || b.align === 'left' ? 'auto' : (b.align === 'right' ? '0' : '');
      if (b.src) { var im = q('img', fg); if (im) im.src = b.src; }
      applyCrop(fg, b.crop);
    }
  }
  function buildAdded(rec) {
    var el, im, cap;
    if (rec.type === 'panel') { el = document.createElement('section'); el.className = 'panel c' + (rec.cls ? ' ' + rec.cls : ''); el.innerHTML = clean(rec.html); }
    else if (rec.type === 'li') { el = document.createElement('li'); el.innerHTML = clean(rec.html); }
    else {
      var fig = '<figure class="fig' + (rec.type === 'pic' ? ' center' : '') + '"><img alt=""><figcaption></figcaption></figure>';
      if (rec.type === 'pic') { el = document.createElement('section'); el.className = 'panel wide'; el.innerHTML = fig; }
      else { el = document.createElement('div'); el.innerHTML = fig; el = el.firstChild; }
      im = q('img', el); im.src = rec.src || ''; cap = q('figcaption', el); cap.innerHTML = clean(rec.cap || 'Type a caption');
    }
    el.setAttribute('data-kb', rec.id); el.setAttribute('data-added', rec.type); el.setAttribute('data-aid', rec.id);
    return el;
  }
  function blockKids(c) { return Array.prototype.slice.call(c.children).filter(function (k) { return k.hasAttribute('data-kb'); }); }
  function reorder(c, keys) {
    var kids = Array.prototype.slice.call(c.children), idx = [];
    kids.forEach(function (k, i) { if (k.hasAttribute('data-kb')) idx.push(i); });
    var blocks = idx.map(function (i) { return kids[i]; });
    var sorted = blocks.slice().sort(function (a, b) {
      var ia = keys.indexOf(a.getAttribute('data-kb')), ib = keys.indexOf(b.getAttribute('data-kb'));
      if (ia < 0) ia = 1e6 + blocks.indexOf(a); if (ib < 0) ib = 1e6 + blocks.indexOf(b); return ia - ib;
    });
    var out = kids.slice(); idx.forEach(function (pos, n) { out[pos] = sorted[n]; });
    out.forEach(function (k) { c.appendChild(k); });
  }
  function applyAll(root) {
    var cs = qa('[data-kc]', root); if (root.hasAttribute && root.hasAttribute('data-kc')) cs.push(root);
    cs.forEach(function (c) {
      (E.add[c.getAttribute('data-kc')] || []).forEach(function (rec) {
        var have = Array.prototype.slice.call(c.children).some(function (k) { return k.getAttribute('data-aid') === rec.id; });
        if (!have) c.appendChild(buildAdded(rec));
      });
    });
    qa('[data-kt]', root).forEach(function (el) {
      var k = el.getAttribute('data-kt');
      if (E.text[k] !== undefined) el.innerHTML = clean(E.text[k]); else if (el.__orig !== undefined && el.innerHTML !== el.__orig) el.innerHTML = el.__orig;
      setTextStyle(el, E.style[k]);
      if (E.style[k] && E.style[k].tr) el.setAttribute('data-kfree', '1'); else el.removeAttribute('data-kfree');
    });
    qa('[data-kb]', root).forEach(function (el) {
      var k = el.getAttribute('data-kb'); applyBlock(el, E.block[k]); el.classList.toggle('ed-hidden', !!E.hide[k]);
    });
    cs.forEach(function (c) {
      var ck = c.getAttribute('data-kc'); if (E.order[ck]) reorder(c, E.order[ck]);
      var n = E.cols[ck]; c.style.gridTemplateColumns = n ? 'repeat(' + n + ',minmax(0,1fr))' : '';
    });
  }

  /* ---------- called by the page after it draws something ---------- */
  function after(viewKey, root, opts) {
    var blocks = !(opts && opts.blocks === false);
    curView = viewKey; curRoot = root; deselect();
    tagAll(root, viewKey, blocks);
    applyAll(root);
    if (editing) decorate(root); else undecorate(root);
  }
  function focusView(viewKey, root) { curView = viewKey; curRoot = root; deselect(); if (editing) decorate(root); else undecorate(root); }
  function undecorate(root) { qa('[contenteditable]', root).forEach(function (n) { n.removeAttribute('contenteditable'); n.removeAttribute('spellcheck'); }); }
  function decorate(root) {
    qa('[data-kt]', root).forEach(function (el) { el.setAttribute('contenteditable', 'true'); el.setAttribute('spellcheck', 'false'); });
    qa('[data-added]', root).forEach(function (b) {
      if (b.getAttribute('data-added') === 'li') { b.setAttribute('contenteditable', 'true'); return; }
      qa('h1,h2,h3,p,figcaption', b).forEach(function (t) { t.setAttribute('contenteditable', 'true'); t.setAttribute('spellcheck', 'false'); });
    });
    qa('img', root).forEach(function (i) { i.draggable = false; });
    qa('a', root).forEach(function (a) { a.draggable = false; });
  }

  /* ---------- changes, undo and the draft ---------- */
  var draftT = null;
  function sizeKB() { return Math.round(JSON.stringify(E).length / 1024); }
  function changedFromPublished() { return JSON.stringify(E) !== JSON.stringify(pub); }
  function saveDraft() {
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify(E)); draftWarned = false; }
    catch (e) { if (!draftWarned) { draftWarned = true; toast('Your changes are too big to keep as a draft. Press "Save my changes" now so you do not lose them.'); } }
    status();
  }
  function dirty() { clearTimeout(draftT); draftT = setTimeout(saveDraft, 300); status(); }
  function commit() { if (JSON.stringify(E) === JSON.stringify(hist[hist.length - 1])) { dirty(); return; } hist.push(snap(E)); if (hist.length > 40) hist.shift(); redo = []; dirty(); }
  function status() {
    var s = q('#edStatus'); if (!s) return;
    s.textContent = (changedFromPublished() ? 'Not published yet' : 'Matches the published page') + ' \u00b7 edits.js ' + sizeKB() + ' KB';
    s.className = changedFromPublished() ? 'ed-warn' : '';
  }
  function rerender() {
    deselect();
    if (curView === 'folio') { saveDraft(); location.reload(); return; }
    var y = window.scrollY; if (window.route) window.route(); window.scrollTo(0, y); applyGlobal(); status();
  }
  function undo() { commit(); if (hist.length < 2) return; redo.push(hist.pop()); E = norm(snap(hist[hist.length - 1])); dirty(); applyGlobal(); rerender(); }
  function redoIt() { if (!redo.length) return; var s = redo.pop(); hist.push(s); E = norm(snap(s)); dirty(); applyGlobal(); rerender(); }

  /* ---------- selection ---------- */
  function textOf(el) { return el && el.closest ? el.closest('[data-kt],[data-added] h1,[data-added] h2,[data-added] h3,[data-added] p,[data-added] figcaption,[data-added][data-added="li"]') : null; }
  function blockOf(el) { return el && el.closest ? el.closest('[data-kb]') : null; }
  function select(el) {
    var pb = sel ? (sel.hasAttribute('data-kb') ? sel : blockOf(sel)) : null;
    if (sel) sel.classList.remove('ed-sel');
    sel = el; if (sel) sel.classList.add('ed-sel');
    if (cropMode && selBlock() !== pb) { cropMode = false; document.body.classList.remove('ed-cropmode'); }
    updateBar(); place();
  }
  function deselect() { select(null); }
  function selBlock() { return sel ? (sel.hasAttribute('data-kb') ? sel : blockOf(sel)) : null; }
  function selText() { return sel && (sel.hasAttribute('data-kt') || textOf(sel) === sel) ? sel : null; }
  function textTargets() {
    if (!sel) return [];
    if (selText()) return [sel];
    return qa('[data-kt],[data-added] h1,[data-added] h2,[data-added] h3,[data-added] p,[data-added] figcaption', sel);
  }
  function figOf() { return figTarget(selBlock()); }
  function isFig() { return !!figTarget(selBlock()); }

  /* ---------- editing text ---------- */
  function recFor(block) {
    var id = block.getAttribute('data-aid'), found = null;
    Object.keys(E.add).forEach(function (ck) { E.add[ck].forEach(function (r) { if (r.id === id) found = r; }); });
    return found;
  }
  function stripDeco(node) {
    var c = node.cloneNode(true);
    [c].concat(qa('*', c)).forEach(function (n) {
      ['contenteditable', 'spellcheck', 'draggable', 'data-kt', 'data-kb', 'data-kc', 'data-added', 'data-aid'].forEach(function (a) { n.removeAttribute(a); });
      n.classList && n.classList.remove('ed-sel', 'ed-hidden');
    });
    return c;
  }
  function saveAdded(block) {
    var rec = recFor(block); if (!rec) return;
    var c = stripDeco(block);
    if (rec.type === 'panel' || rec.type === 'li') rec.html = clean(c.innerHTML);
    else { var cap = q('figcaption', c); rec.cap = cap ? clean(cap.innerHTML) : ''; }
    dirty();
  }
  function persistText(el) {
    var added = el.closest('[data-added]');
    if (added && !el.hasAttribute('data-kt')) { saveAdded(added); return; }
    var k = el.getAttribute('data-kt'), s = readTextStyle(el);
    if (Object.keys(s).length) E.style[k] = s; else delete E.style[k];
    var html = clean(el.innerHTML);
    if (el.__orig !== undefined && html === clean(el.__orig)) delete E.text[k]; else E.text[k] = html;
    dirty();
  }
  function patchStyle(patch) {
    textTargets().forEach(function (el) {
      Object.keys(patch).forEach(function (k) { el.style[STYLE_PROPS[k]] = patch[k] || ''; });
      persistText(el);
    });
    commit(); updateBar();
  }
  function curSize() { var t = textTargets()[0]; return t ? Math.round(parseFloat(getComputedStyle(t).fontSize)) : 0; }
  function bumpSize(d) {
    textTargets().forEach(function (el) {
      var cur = parseFloat(getComputedStyle(el).fontSize), n = Math.max(10, Math.min(120, Math.round(cur + d)));
      el.style.fontSize = n + 'px'; persistText(el);
    });
    commit(); updateBar();
  }
  function fmt(kind) {
    var s = window.getSelection(), t = selText();
    if (t && s && s.rangeCount && !s.isCollapsed && t.contains(s.anchorNode) && document.execCommand) {
      document.execCommand(kind === 'b' ? 'bold' : kind === 'i' ? 'italic' : 'underline'); persistText(t); commit(); return;
    }
    var cs = textTargets()[0] ? getComputedStyle(textTargets()[0]) : null; if (!cs) return;
    if (kind === 'b') patchStyle({ fw: parseInt(cs.fontWeight, 10) >= 600 ? '400' : '700' });
    if (kind === 'i') patchStyle({ fi: cs.fontStyle === 'italic' ? 'normal' : 'italic' });
    if (kind === 'u') patchStyle({ td: /underline/.test(cs.textDecorationLine || cs.textDecoration) ? 'none' : 'underline' });
  }
  function rgbToHex(rgb) { var m = String(rgb).match(/\d+/g); if (!m) return '#000000'; return '#' + m.slice(0, 3).map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join(''); }
  document.addEventListener('input', function (e) {
    if (!editing) return;
    var el = e.target.closest && e.target.closest('[contenteditable="true"]'); if (!el) return;
    if (el.hasAttribute('data-kt')) persistText(el); else { var b = el.closest('[data-added]'); if (b) saveAdded(b); }
  });
  document.addEventListener('focusout', function (e) {
    if (!editing) return;
    var el = e.target.closest && e.target.closest('[contenteditable="true"]'); if (el) commit();
  });
  document.addEventListener('paste', function (e) {
    if (!editing || !(e.target.closest && e.target.closest('[contenteditable="true"]'))) return;
    e.preventDefault(); var t = (e.clipboardData || window.clipboardData).getData('text/plain'); document.execCommand && document.execCommand('insertText', false, t);
  });

  /* ---------- blocks: move, width, delete ---------- */
  function recordOrder(c) { E.order[c.getAttribute('data-kc')] = blockKids(c).map(function (k) { return k.getAttribute('data-kb'); }); }
  function moveBlock(dir) {
    var b = selBlock(); if (!b) return;
    var sib = b; do { sib = dir < 0 ? sib.previousElementSibling : sib.nextElementSibling; } while (sib && !sib.hasAttribute('data-kb'));
    if (!sib) return;
    if (dir < 0) b.parentElement.insertBefore(b, sib); else b.parentElement.insertBefore(b, sib.nextSibling);
    if (b.parentElement.hasAttribute('data-kc')) recordOrder(b.parentElement);
    commit(); place();
  }
  function blk(k) { return E.block[k] || (E.block[k] = {}); }
  function setSpan(v) {
    var b = selBlock(); if (!b) return; var k = b.getAttribute('data-kb'); var o = blk(k);
    if (v) o.span = v; else delete o.span; if (!Object.keys(o).length) delete E.block[k];
    applyBlock(b, E.block[k]); commit(); place();
  }
  function toggleDelete() {
    var b = selBlock(); if (!b) return; var k = b.getAttribute('data-kb');
    if (b.hasAttribute('data-added')) {
      var ck = b.parentElement.getAttribute('data-kc'); E.add[ck] = (E.add[ck] || []).filter(function (r) { return r.id !== b.getAttribute('data-aid'); });
      if (!E.add[ck].length) delete E.add[ck];
      delete E.block[k]; if (E.order[ck]) E.order[ck] = E.order[ck].filter(function (x) { return x !== k; });
      b.remove(); deselect(); commit(); return;
    }
    if (E.hide[k]) delete E.hide[k]; else E.hide[k] = true;
    b.classList.toggle('ed-hidden', !!E.hide[k]); commit(); updateBar();
  }
  function selectParent() {
    if (!sel) return; var b = selBlock(), start = (b === sel) ? sel.parentElement : b; var p = start && start.closest ? start.closest('[data-kb]') : null;
    if (b && b !== sel) { select(b); return; }
    if (p) select(p);
  }
  function setCols(n) {
    var c = containerOf(); if (!c) return; var ck = c.getAttribute('data-kc');
    if (n) E.cols[ck] = n; else delete E.cols[ck];
    c.style.gridTemplateColumns = n ? 'repeat(' + n + ',minmax(0,1fr))' : ''; commit(); place();
  }
  function containerOf() { var b = selBlock(); var c = b ? b.parentElement : (sel && sel.hasAttribute && sel.hasAttribute('data-kc') ? sel : null); return c && c.hasAttribute('data-kc') ? c : null; }

  /* ---------- pictures ---------- */
  function toDataURL(file, maxW) {
    return new Promise(function (res, rej) {
      var u = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var s = Math.min(1, maxW / im.naturalWidth), c = document.createElement('canvas'); c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', 0.82));
      };
      im.onerror = function () { URL.revokeObjectURL(u); rej(new Error('bad image')); }; im.src = u;
    });
  }
  function pickImage() {
    return new Promise(function (res) {
      var f = q('#edFile'); f.value = ''; f.onchange = function () { if (f.files[0]) toDataURL(f.files[0], 900).then(res).catch(function () { toast('I could not read that picture. Try a JPG or PNG.'); }); }; f.click();
    });
  }
  function figWidthBy(mult) {
    var b = selBlock(), f = figOf(); if (!f) return; var k = b.getAttribute('data-kb'), w = f.getBoundingClientRect().width * mult;
    var max = f.parentElement ? f.parentElement.getBoundingClientRect().width : 2000;
    w = Math.round(Math.max(80, Math.min(max, w))); blk(k).w = w; applyBlock(b, E.block[k]); commit(); place();
  }
  function figAlign(a) { var b = selBlock(); if (!figOf()) return; var k = b.getAttribute('data-kb'); blk(k).align = a; applyBlock(b, E.block[k]); commit(); place(); }
  function figReset() { var b = selBlock(); if (!figOf()) return; var k = b.getAttribute('data-kb'); var o = blk(k); delete o.w; delete o.align; if (!Object.keys(o).length) delete E.block[k]; applyBlock(b, E.block[k]); commit(); place(); }
  function setPicture(b, url) {
    var fg = figTarget(b); if (!fg) return; var k = b.getAttribute('data-kb'); q('img', fg).src = url;
    if (b.hasAttribute('data-added')) { var rec = recFor(b); if (rec) rec.src = url; } else blk(k).src = url;
    commit();
  }
  function replacePicture() {
    var b = selBlock(); if (!figOf()) return;
    pickImage().then(function (url) { setPicture(b, url); toast('Picture replaced. Pictures make edits.js bigger (see the size at the bottom).'); });
  }
  /* crop, zoom, pan and flip: non-destructive, the original picture is never changed */
  function setCrop(patch, live) {
    var b = selBlock(); if (!figOf()) return; var k = b.getAttribute('data-kb'), o = blk(k);
    if (patch === null) delete o.crop;
    else {
      var c = Object.assign({}, CROP0, o.crop || {}, patch);
      c.z = Math.max(1, Math.min(4, c.z)); c.px = Math.max(0, Math.min(100, c.px)); c.py = Math.max(0, Math.min(100, c.py)); o.crop = c;
    }
    if (!Object.keys(o).length) delete E.block[k];
    applyBlock(b, E.block[k]); if (!live) commit(); updateBar(); place();
  }
  function curCrop() { var b = selBlock(); return b && E.block[b.getAttribute('data-kb')] ? E.block[b.getAttribute('data-kb')].crop : null; }
  function toggleCropMode() {
    if (!isFig()) return; cropMode = !cropMode; document.body.classList.toggle('ed-cropmode', cropMode);
    if (cropMode && !curCrop()) setCrop({}); updateBar();
  }
  function pruned() {
    var o = copy(E);
    Object.keys(o.block).forEach(function (k) {
      var c = o.block[k].crop;
      if (c && c.ar === 'orig' && (c.z || 1) === 1 && (c.px == null || c.px === 50) && (c.py == null || c.py === 50) && !c.flip) delete o.block[k].crop;
      if (!Object.keys(o.block[k]).length) delete o.block[k];
    });
    return o;
  }
  function addRecord(c, rec) {
    var ck = c.getAttribute('data-kc');
    E.add[ck] = (E.add[ck] || []).concat(rec); var el = buildAdded(rec); c.appendChild(el); applyBlock(el, E.block[rec.id]); decorate(c);
    recordOrder(c); commit(); select(el); el.scrollIntoView({ block: 'center' });
  }
  function newId() { return 'add-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function addTo(type) {
    var c = containerOf(); if (!c) return;
    if (type === 'panel') addRecord(c, { id: newId(), type: 'panel', html: '<h2>New heading</h2><p>Click here and type your text.</p>' });
    else if (type === 'li') addRecord(c, { id: newId(), type: 'li', html: 'New item. Click to type.' });
    else pickImage().then(function (url) { addRecord(c, { id: newId(), type: type, src: url, cap: 'Type a caption' }); });
  }
  /* dragging picture files from the computer onto the page */
  function hasFiles(dt) { return !!dt && Array.prototype.indexOf.call(dt.types || [], 'Files') > -1; }
  function dropContainer(t) {
    var c = t.closest && t.closest('.gallery,.refgrid,.lgrid'); return c && c.hasAttribute('data-kc') ? c : null;
  }
  function dropTarget(t) { var b = t.closest && t.closest('[data-kb]'); return b && figTarget(b) ? b : dropContainer(t); }
  function clearDrop() { qa('.ed-dropping').forEach(function (n) { n.classList.remove('ed-dropping'); }); }
  function handleDrop(target, files) {
    if (!target) { toast('Drop a picture onto another picture to replace it, or onto a picture group or lesson to add it.'); return Promise.resolve(); }
    if (target.hasAttribute('data-kb') && figTarget(target)) {
      return toDataURL(files[0], 900).then(function (url) { select(target); setPicture(target, url); toast('Picture replaced.'); });
    }
    return files.reduce(function (ch, f) {
      return ch.then(function () { return toDataURL(f, 900).then(function (url) { addRecord(target, { id: newId(), type: target.matches('.lgrid') ? 'pic' : 'fig', src: url, cap: 'Type a caption' }); }); });
    }, Promise.resolve());
  }

  /* ---------- the toolbar ---------- */
  var ovMoveDrag = false;
  function el(tag, attrs, html) { var e = document.createElement(tag); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); if (html) e.innerHTML = html; return e; }
  function toast(msg) {
    var t = q('#edToast'); if (!t) return; t.textContent = msg; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(function () { t.hidden = true; }, 6000);
  }
  function build() {
    if (q('#edBar')) return;
    var fontOpts = FONTS.map(function (f) { return '<option value="' + f[1].replace(/"/g, '&quot;') + '">' + f[0] + '</option>'; }).join('');
    var bar = el('div', { id: 'edBar', hidden: '' }, [
      '<div class="ed-row">',
      '<strong>✏️ Editing</strong>',
      '<label>Page <select id="edPage"></select></label>',
      '<button type="button" id="edUndo">↶ Undo</button><button type="button" id="edRedo">↷ Redo</button>',
      '<button type="button" id="edPreview">👁 Preview</button>',
      '<button type="button" id="edPresent" title="Hide everything except the lesson, for the projector">▶ Present</button>',
      '<button type="button" id="edSave" class="ed-primary">💾 Save my changes</button>',
      '<button type="button" id="edHelpBtn">? Help</button><button type="button" id="edExit">Exit</button>',
      '<span id="edStatus"></span></div>',
      '<div class="ed-row" id="edTplRow"><span class="ed-label">Add to this lesson:</span><button type="button" data-tpl="objective">🎯 Objective box</button><button type="button" data-tpl="vocab">📖 Vocabulary card</button><button type="button" data-tpl="prompt">💬 Discussion prompt</button><button type="button" data-tpl="text">Text box</button><button type="button" data-tpl="h1">Heading 1</button><button type="button" data-tpl="h2">Heading 2</button><button type="button" data-tpl="rect">▭ Rectangle</button><button type="button" data-tpl="circle">◯ Circle</button><button type="button" data-tpl="pic">🖼 Picture</button></div>',
      '<div class="ed-row ed-ctx"><span id="edSelLabel" class="ed-label">Click any text, picture or box to edit it.</span>',
      '<span class="ed-grp" id="gText" hidden><select id="edFont" aria-label="Font">' + fontOpts + '</select>',
      '<button type="button" id="edSm" title="Smaller text">A−</button><span id="edSize" class="ed-size"></span><button type="button" id="edLg" title="Bigger text">A+</button>',
      '<button type="button" id="edB"><b>B</b></button><button type="button" id="edI"><i>I</i></button><button type="button" id="edU"><u>U</u></button>',
      '<label class="ed-col" title="Text colour">Colour <input type="color" id="edColor" value="#000000"></label>',
      '<button type="button" id="edAL" title="Align left">⯇</button><button type="button" id="edAC" title="Centre">≡</button><button type="button" id="edAR" title="Align right">⯈</button>',
      '<button type="button" id="edClearFmt">Clear formatting</button></span>',
      '<span class="ed-grp" id="gBlock" hidden><button type="button" id="edPrevB">◀ Earlier</button><button type="button" id="edNextB">Later ▶</button>',
      '<button type="button" id="edNarrow">Half width</button><button type="button" id="edWide">Full width</button><button type="button" id="edAuto">Auto width</button>',
      '<button type="button" id="edDel">🗑 Delete</button><button type="button" id="edUp">⬆ Select parent</button><button type="button" id="edFreeReset" hidden>↺ Reset position</button></span>',
      '<span class="ed-grp" id="gFx" hidden><label>Fill <input type="color" id="edFill" value="#ffffff"></label><button type="button" id="edNoFill">No fill</button><label>Border <input type="color" id="edBdc" value="#2b5be0"></label><select id="edBdw" aria-label="Border width"><option value="0">No border</option><option value="1">1 px</option><option value="2">2 px</option><option value="3">3 px</option><option value="4">4 px</option><option value="6">6 px</option><option value="8">8 px</option></select><label>Opacity <input type="range" id="edOp" min="10" max="100" step="5" value="100"> <span id="edOpV" class="ed-size">100%</span></label></span>'+
      '<span class="ed-grp" id="gImg" hidden><button type="button" id="edImgSm">Picture −</button><button type="button" id="edImgLg">Picture +</button>',
      '<button type="button" id="edImgL">Left</button><button type="button" id="edImgC">Centre</button><button type="button" id="edImgR">Right</button>',
      '<button type="button" id="edImgReset">Reset size</button><button type="button" id="edImgNew">Replace picture…</button></span>',
      '<span class="ed-grp" id="gCrop" hidden><button type="button" id="edCropMode">✂ Crop &amp; zoom</button>',
      '<label>Shape <select id="edAspect"><option value="off">No crop</option><option value="orig">Original shape</option><option value="1/1">Square 1:1</option><option value="4/3">Landscape 4:3</option><option value="3/2">Landscape 3:2</option><option value="16/9">Wide 16:9</option><option value="3/4">Portrait 3:4</option></select></label>',
      '<label>Zoom <input type="range" id="edZoom" min="100" max="400" step="5" value="100"> <span id="edZoomV" class="ed-size">100%</span></label>',
      '<button type="button" id="edFlip">⇆ Flip</button><button type="button" id="edCropReset">Reset crop</button>',
      '<span class="ed-label" id="edCropHint" hidden>Drag the picture to move it inside the frame. Scroll to zoom.</span></span>',
      '<span class="ed-grp" id="gCont" hidden><span class="ed-label">Columns</span><button type="button" data-cols="1">1</button><button type="button" data-cols="2">2</button><button type="button" data-cols="3">3</button><button type="button" data-cols="4">4</button><button type="button" data-cols="0">Auto</button>',
      '<button type="button" id="edAddPanel">+ Text box</button><button type="button" id="edAddPic">+ Picture</button><button type="button" id="edAddItem">+ Item</button></span></div>',
      '<div class="ed-row"><span class="ed-label">Whole page:</span>',
      '<label>Text font <select id="edGBody">' + fontOpts + '</select></label><label>Heading font <select id="edGHead">' + fontOpts + '</select></label>',
      '<button type="button" id="edGSm">Page text −</button><span id="edGScale" class="ed-size"></span><button type="button" id="edGLg">Page text +</button>',
      '<button type="button" id="edClearAdded">🧹 Clear added items</button><button type="button" id="edDlLesson">⬇ Download lesson (.html)</button><button type="button" id="edResetPage">Undo all on this page</button><button type="button" id="edDiscard">Discard all unsaved changes</button></div>'
    ].join(''));
    var prev = el('div', { id: 'edPrev', hidden: '' }, 'Preview with your unsaved changes. <button type="button" id="edBack">Back to editing</button> <button type="button" id="edExit2">Exit</button>');
    var ov = el('div', { id: 'edOv', hidden: '' }, '<button type="button" id="edMove" draggable="true" title="Drag to move">⠿ Move</button><button type="button" id="edFree" title="Drag to place it anywhere you like">✥ Free</button><span id="edResize" title="Drag to resize"></span>');
    var file = el('input', { type: 'file', id: 'edFile', accept: 'image/*', hidden: '' });
    var toastEl = el('div', { id: 'edToast', hidden: '', role: 'status' });
    var help = el('dialog', { id: 'edHelp' }, [
      '<h2>How editing works</h2><ul>',
      '<li><b>Retype:</b> click any text and type. Pasted text loses its formatting.</li>',
      '<li><b>Font, size, colour, alignment:</b> click some text, then use the bar. Select a whole box (Select parent) to change everything in it.</li>',
      '<li><b>Move:</b> select a box or picture, then drag the ⠿ Move handle, or press Earlier / Later.</li>',
      '<li><b>Resize a picture:</b> select it and drag the little square at its bottom-right corner.</li>',
      '<li><b>Drag and drop pictures:</b> drag a JPG or PNG from your computer onto a picture to replace it, or onto a picture group or lesson to add it.</li>',
      '<li><b>Crop, zoom, flip:</b> select a picture, press “✂ Crop &amp; zoom”, pick a shape, then drag inside the picture to move it and use the Zoom slider or mouse wheel. The original picture is never changed.</li>',
      '<li><b>Layout:</b> select any box inside a group and choose 1 to 4 columns, or make one box half or full width.</li>',
      '<li><b>Add and delete:</b> select a box and use + Text box, + Picture or + Item. Delete fades something out; press it again to bring it back.</li>',
      '<li><b>Free move:</b> select any text or box, then drag the purple ✥ Free handle to put it anywhere you like (on computers; phones keep the normal layout). Press ↺ Reset position to put it back.</li>',
      '<li><b>Add:</b> use the “Add to this lesson” buttons for an objective box, vocabulary card, discussion prompt, text box, headings, shapes or a picture. Then drag ✥ Free to place it, and the square corner to resize it.</li>',
      '<li><b>Fill, border, opacity:</b> select a box and use the Fill, Border and Opacity controls.</li>',
      '<li><b>Present:</b> hides everything except the lesson, ready for the projector. Press Esc to come back.</li>',
      '<li><b>Clear added items</b> removes everything you added to this page (press Undo straight after to bring it back). <b>Download lesson</b> saves this page as a stand-alone .html file.</li>',
      '<li><b>Save:</b> press “Save my changes”. It downloads <b>' + EDITS_FILE + '</b>. Upload that file to GitHub next to the page (replace the old one) and commit.</li>',
      '<li>Your work is kept as a draft in this browser, so you can stop and carry on later. Students never see your draft until you publish edits.js.</li></ul>',
      '<p><button type="button" class="ed-primary" id="edHelpClose">Got it</button></p>'
    ].join(''));
    document.body.appendChild(bar); document.body.appendChild(prev); document.body.appendChild(ov); document.body.appendChild(file); document.body.appendChild(toastEl); document.body.appendChild(help);
    wire();
  }
  function wire() {
    var bar = q('#edBar');
    bar.addEventListener('mousedown', function (e) { if (!e.target.closest('select,input')) e.preventDefault(); });
    bar.addEventListener('click', function (e) { var tb = e.target.closest('[data-tpl]'); if (tb) addTpl(tb.getAttribute('data-tpl')); });
    q('#edFill').addEventListener('input', function (e) { setFx({ bg: e.target.value }, false); }); q('#edFill').addEventListener('change', function () { commit(); updateBar(); });
    q('#edNoFill').addEventListener('click', function () { var b = selBlock(); if (!b) return; var r = E.block[b.getAttribute('data-kb')] || {}; if (r.bg === 'transparent') setFx({ bg: r.bgp || null, bgp: null }); else setFx({ bg: 'transparent', bgp: r.bg || null }); });
    q('#edBdc').addEventListener('input', function (e) { var b = selBlock(); if (!b) return; var r = blk(b.getAttribute('data-kb')); setFx({ bd: e.target.value, bdw: r.bdw === undefined ? (parseFloat(getComputedStyle(b).borderTopWidth) || 2) : r.bdw }, false); }); q('#edBdc').addEventListener('change', function () { commit(); updateBar(); });
    q('#edBdw').addEventListener('change', function (e) { setFx({ bdw: +e.target.value }); });
    q('#edOp').addEventListener('input', function (e) { q('#edOpV').textContent = e.target.value + '%'; setFx({ op: e.target.value / 100 }, false); }); q('#edOp').addEventListener('change', function () { commit(); });
    q('#edPresent').addEventListener('click', function () { present(true); }); q('#edClearAdded').addEventListener('click', clearAdded); q('#edDlLesson').addEventListener('click', downloadLesson);
    function on(id, fn) { q('#' + id).addEventListener('click', fn); }
    on('edUndo', undo); on('edRedo', redoIt); on('edSave', download);
    on('edPreview', function () { editing = false; sessionStorage.setItem(EDIT_FLAG, '0'); mode(); rerender(); });
    on('edBack', function () { editing = true; sessionStorage.setItem(EDIT_FLAG, '1'); mode(); rerender(); });
    on('edExit', exit); on('edExit2', exit);
    on('edHelpBtn', function () { q('#edHelp').showModal(); }); on('edHelpClose', function () { q('#edHelp').close(); });
    on('edSm', function () { bumpSize(-2); }); on('edLg', function () { bumpSize(2); });
    on('edB', function () { fmt('b'); }); on('edI', function () { fmt('i'); }); on('edU', function () { fmt('u'); });
    on('edAL', function () { patchStyle({ ta: 'left' }); }); on('edAC', function () { patchStyle({ ta: 'center' }); }); on('edAR', function () { patchStyle({ ta: 'right' }); });
    on('edClearFmt', function () { patchStyle({ ff: '', fs: '', c: '', fw: '', fi: '', td: '', ta: '' }); });
    q('#edFont').addEventListener('change', function (e) { patchStyle({ ff: e.target.value }); });
    q('#edColor').addEventListener('input', function (e) { textTargets().forEach(function (t) { t.style.color = e.target.value; persistText(t); }); });
    q('#edColor').addEventListener('change', function () { commit(); });
    on('edPrevB', function () { moveBlock(-1); }); on('edNextB', function () { moveBlock(1); });
    on('edNarrow', function () { setSpan('1'); }); on('edWide', function () { setSpan('full'); }); on('edAuto', function () { setSpan(''); });
    on('edDel', toggleDelete); on('edUp', selectParent);
    on('edImgSm', function () { figWidthBy(0.85); }); on('edImgLg', function () { figWidthBy(1.18); });
    on('edImgL', function () { figAlign('left'); }); on('edImgC', function () { figAlign('center'); }); on('edImgR', function () { figAlign('right'); });
    on('edImgReset', figReset); on('edImgNew', replacePicture);
    qa('[data-cols]', bar).forEach(function (b) { b.addEventListener('click', function () { setCols(+b.getAttribute('data-cols')); }); });
    on('edAddPanel', function () { addTo('panel'); }); on('edAddPic', function () { var c = containerOf(); addTo(c && c.matches('.lgrid') ? 'pic' : 'fig'); }); on('edAddItem', function () { addTo('li'); });
    q('#edPage').addEventListener('change', function (e) { location.hash = e.target.value; });
    q('#edGBody').addEventListener('change', function (e) { E.global.body = e.target.value; if (!e.target.value) delete E.global.body; applyGlobal(); commit(); });
    q('#edGHead').addEventListener('change', function (e) { E.global.display = e.target.value; if (!e.target.value) delete E.global.display; applyGlobal(); commit(); });
    on('edGSm', function () { gScale(-5); }); on('edGLg', function () { gScale(5); });
    on('edResetPage', function () {
      if (!window.confirm('Undo every change you made on this page?')) return;
      ['text', 'style', 'block', 'order', 'hide', 'cols', 'add'].forEach(function (m) { Object.keys(E[m]).forEach(function (k) { if (k.indexOf(curView + '|') === 0) delete E[m][k]; }); });
      commit(); rerender();
    });
    on('edDiscard', function () {
      if (!window.confirm('Throw away ALL unsaved changes and go back to the published page?')) return;
      E = copy(pub); hist = [snap(E)]; redo = []; try { localStorage.removeItem(DRAFT_KEY); } catch (e) {} applyGlobal(); rerender(); status();
    });
    /* move and resize handles */
    var mv = q('#edMove');
    q('#edFree').addEventListener('pointerdown', startFree);
    q('#edFreeReset').addEventListener('click', function () { var t = freeTarget(); if (!t) return; t.style.transform = ''; t.removeAttribute('data-kfree'); saveFree(t); });
    mv.addEventListener('dragstart', function (e) { dragEl = selBlock(); if (!dragEl) { e.preventDefault(); return; } e.dataTransfer.setData('text/plain', 'move'); e.dataTransfer.effectAllowed = 'move'; dragEl.classList.add('ed-dragging'); });
    mv.addEventListener('dragend', function () { if (dragEl) { dragEl.classList.remove('ed-dragging'); if (dragEl.parentElement.hasAttribute('data-kc')) recordOrder(dragEl.parentElement); commit(); dragEl = null; place(); } });
    document.addEventListener('dragover', function (e) {
      if (!dragEl) return; var t = e.target.closest && e.target.closest('[data-kb]');
      while (t && t.parentElement !== dragEl.parentElement) t = t.parentElement && t.parentElement.closest ? t.parentElement.closest('[data-kb]') : null;
      if (!t || t === dragEl) return; e.preventDefault(); var r = t.getBoundingClientRect();
      var before = (e.clientY < r.top + r.height / 2) && (e.clientX < r.left + r.width * 0.75) || (e.clientX < r.left + r.width / 2 && Math.abs(e.clientY - (r.top + r.height / 2)) < r.height / 2);
      t.parentElement.insertBefore(dragEl, before ? t : t.nextSibling); place();
    });
    var rz = q('#edResize'), rs = null;
    rz.addEventListener('pointerdown', function (e) {
      var f = figOf(), bx = f ? null : boxTarget(); if (!f && !bx) return; e.preventDefault(); rz.setPointerCapture(e.pointerId);
      if (f) rs = { f: f, x: e.clientX, w: f.getBoundingClientRect().width, max: f.parentElement.getBoundingClientRect().width };
      else { var r0 = bx.getBoundingClientRect(); rs = { box: bx, x: e.clientX, y: e.clientY, w: r0.width, h: r0.height }; }
    });
    rz.addEventListener('pointermove', function (e) {
      if (!rs) return;
      if (rs.box) { rs.box.style.maxWidth = '100%'; rs.box.style.width = Math.round(Math.max(80, rs.w + (e.clientX - rs.x))) + 'px'; rs.box.style.minHeight = Math.round(Math.max(40, rs.h + (e.clientY - rs.y))) + 'px'; place(); return; }
      var w = Math.max(80, Math.min(rs.max, rs.w + (e.clientX - rs.x)));
      rs.f.style.width = Math.round(w) + 'px'; rs.f.style.maxWidth = '100%'; place();
    });
    function endRz(e) {
      if (!rs) return;
      if (rs.box) { var kb = rs.box.getAttribute('data-kb'), rr = blk(kb); rr.bw = Math.round(parseFloat(rs.box.style.width)); rr.bh = Math.round(parseFloat(rs.box.style.minHeight)); }
      else { var k = rs.f.getAttribute('data-kb'); blk(k).w = Math.round(parseFloat(rs.f.style.width)); }
      rs = null; try { rz.releasePointerCapture(e.pointerId); } catch (x) {} commit(); place();
    }
    rz.addEventListener('pointerup', endRz); rz.addEventListener('pointercancel', endRz);
    window.addEventListener('resize', place); window.addEventListener('scroll', function () {}, { passive: true });
    document.addEventListener('keydown', function (e) { if (editing && e.key === 'Escape') deselect(); });
    on('edCropMode', toggleCropMode); on('edFlip', function () { var c = curCrop(); setCrop({ flip: c && c.flip ? 0 : 1 }); }); on('edCropReset', function () { setCrop(null); });
    q('#edAspect').addEventListener('change', function (e) { if (e.target.value === 'off') setCrop(null); else setCrop({ ar: e.target.value }); });
    q('#edZoom').addEventListener('input', function (e) { if (!curCrop()) setCrop({}, true); setCrop({ z: +e.target.value / 100 }, true); });
    q('#edZoom').addEventListener('change', function () { commit(); });
    /* drag inside a cropped picture to move it; wheel to zoom */
    var pan = null;
    document.addEventListener('pointerdown', function (e) {
      if (!editing || !cropMode) return; var wrap = e.target.closest && e.target.closest('.ed-crop'), b = selBlock(), fg = figTarget(b);
      if (!wrap || !fg || wrap.closest('.fig') !== fg) return; var c = curCrop(); if (!c) return;
      e.preventDefault(); pan = { x: e.clientX, y: e.clientY, px: c.px == null ? 50 : c.px, py: c.py == null ? 50 : c.py, wrap: wrap };
    });
    document.addEventListener('pointermove', function (e) {
      if (!pan) return; var im = q('img', pan.wrap), r = pan.wrap.getBoundingClientRect(), wi = parseFloat(im.style.width) || 100, hi = parseFloat(im.style.height) || 100;
      var ox = (wi - 100) / 100 * r.width, oy = (hi - 100) / 100 * r.height, patch = {};
      if (ox > 1) patch.px = pan.px - (e.clientX - pan.x) / ox * 100; if (oy > 1) patch.py = pan.py - (e.clientY - pan.y) / oy * 100;
      setCrop(patch, true);
    });
    document.addEventListener('pointerup', function () { if (pan) { pan = null; commit(); } });
    var wheelT = null;
    document.addEventListener('wheel', function (e) {
      if (!editing || !cropMode) return; var wrap = e.target.closest && e.target.closest('.ed-crop'), b = selBlock(), fg = figTarget(b);
      if (!wrap || !fg || wrap.closest('.fig') !== fg) return; e.preventDefault();
      var c = curCrop() || CROP0; setCrop({ z: (c.z || 1) - e.deltaY / 600 }, true); clearTimeout(wheelT); wheelT = setTimeout(commit, 400);
    }, { passive: false });
    /* drop picture files from the computer */
    document.addEventListener('dragover', function (e) {
      if (!editing || !hasFiles(e.dataTransfer) || (e.target.closest && e.target.closest('.photo,#edBar'))) return;
      e.preventDefault(); clearDrop(); var t = dropTarget(e.target); if (t) t.classList.add('ed-dropping');
    });
    document.addEventListener('dragleave', function (e) { if (!e.relatedTarget) clearDrop(); });
    document.addEventListener('drop', function (e) {
      if (!editing || !hasFiles(e.dataTransfer) || (e.target.closest && e.target.closest('.photo,#edBar'))) return;
      e.preventDefault(); clearDrop();
      var files = Array.prototype.slice.call(e.dataTransfer.files).filter(function (f) { return /^image\//.test(f.type); });
      if (!files.length) { toast('That is not a picture. Use a JPG or PNG.'); return; }
      handleDrop(dropTarget(e.target), files).catch(function () { toast('I could not read that picture. Try a JPG or PNG.'); });
    });
    window.addEventListener('hashchange', syncPage);
  }
  function gScale(d) { var s = (E.global.scale || 100) + d; s = Math.max(70, Math.min(160, s)); if (s === 100) delete E.global.scale; else E.global.scale = s; applyGlobal(); commit(); updateBar(); place(); }

  /* clicks while editing: select instead of following links */
  document.addEventListener('click', function (e) {
    if (!editing) return;
    var t = e.target; if (!t.closest) return;
    if (t.closest('#edBar,#edOv,#edPrev,dialog,.topbar,.foot,#edToast')) return;
    if (!t.closest('#main')) return;
    e.preventDefault(); e.stopPropagation();
    var tx = t.closest('[data-kt],[data-added] h1,[data-added] h2,[data-added] h3,[data-added] p,[data-added] figcaption'), b = t.closest('[data-kb]');
    if (t.closest('.qcard,.slot')) { select(null); return; }
    if (t.closest('img') && b && b.matches('.fig')) { select(b); return; }
    if (tx) { select(tx); return; }
    if (b) { select(b); return; }
    select(t.closest('[data-kc]'));
  }, true);

  function updateBar() {
    if (!editing || !q('#edBar')) return;
    var gt = q('#gText'), gb = q('#gBlock'), gi = q('#gImg'), gc = q('#gCont'), lab = q('#edSelLabel');
    var b = selBlock(), tgt = textTargets(), c = containerOf();
    gt.hidden = !tgt.length; gb.hidden = !b; gi.hidden = !isFig(); gc.hidden = !c; syncFx(); var tr = q('#edTplRow'); if (tr) tr.hidden = !tplContainer();
    var kind = !sel ? '' : (selText() ? 'Text' : isFig() ? 'Picture' : b ? 'Box' : 'Group');
    lab.textContent = !sel ? 'Click any text, picture or box to edit it.' : 'Selected: ' + kind + (b && b.hasAttribute('data-added') ? ' (added by you)' : '') + (b && E.hide[b.getAttribute('data-kb')] ? ' (deleted)' : '');
    if (tgt.length) { q('#edSize').textContent = curSize() + ' px'; try { q('#edColor').value = rgbToHex(getComputedStyle(tgt[0]).color); } catch (e) {} q('#edFont').value = fontVal(tgt[0].style.fontFamily); }
    if (b) q('#edDel').textContent = (b.hasAttribute('data-added') ? '🗑 Remove' : (E.hide[b.getAttribute('data-kb')] ? '↩ Restore' : '🗑 Delete'));
    var narrowOK = !!(b && b.parentElement && getComputedStyle(b.parentElement).display === 'grid');
    q('#edNarrow').hidden = q('#edWide').hidden = q('#edAuto').hidden = !narrowOK;
    if (c) {
      var grid = getComputedStyle(c).display === 'grid';
      qa('[data-cols]').forEach(function (x) { x.hidden = !grid; }); q('#gCont .ed-label').hidden = !grid;
      q('#edAddPanel').hidden = !c.matches('.lgrid'); q('#edAddPic').hidden = !c.matches('.lgrid,.gallery,.refgrid');
      q('#edAddItem').hidden = !c.matches('ol,ul');
    }
    var gcr = q('#gCrop'); gcr.hidden = !isFig();
    if (isFig()) {
      var cr = curCrop(); q('#edAspect').value = cr ? cr.ar : 'off'; q('#edZoom').value = Math.round(((cr && cr.z) || 1) * 100); q('#edZoomV').textContent = Math.round(((cr && cr.z) || 1) * 100) + '%';
      q('#edCropMode').classList.toggle('ed-primary', cropMode); q('#edCropHint').hidden = !cropMode;
    }
    q('#edGScale').textContent = (E.global.scale || 100) + '%';
    q('#edGBody').value = fontVal(E.global.body);
    q('#edGHead').value = fontVal(E.global.display);
    status();
  }
  /* ---------- lesson templates, box styling, present, clear, download ---------- */
  var TPL = {
    objective: { cls: 'ed-tpl ed-tpl-objective', html: '<p><b>Learning Intent:</b> By the end of this lesson, students will be able to...</p>', bw: 640 },
    vocab: { cls: 'ed-tpl ed-tpl-vocab', html: '<p>Keyword</p><p>Write the meaning in words your students will understand.</p>', bw: 640 },
    prompt: { cls: 'ed-tpl ed-tpl-prompt', html: '<p>Discuss: What do you notice, and why do you think that happens?</p>', bw: 640 },
    text: { cls: 'ed-tpl ed-tpl-text', html: '<p>Click here and type your own text.</p>', bw: 440 },
    h1: { cls: 'ed-tpl ed-tpl-h1', html: '<h1>Lesson title</h1>' },
    h2: { cls: 'ed-tpl ed-tpl-h2', html: '<h2>Section heading</h2>' },
    rect: { cls: 'ed-tpl ed-tpl-rect', html: '<p>Label</p>', bw: 340, bh: 200 },
    circle: { cls: 'ed-tpl ed-tpl-circle', html: '<p>Label</p>', bw: 240, bh: 240 }
  };
  function tplContainer() {
    var c = containerOf(); if (c && c.matches('.lgrid')) return c;
    var v = q('#viewLesson'); return v && !v.hidden ? q('.lgrid[data-kc]', v) : null;
  }
  function addTpl(type) {
    var c = tplContainer(); if (!c) { toast('Open a lesson first. Templates are added to lesson pages.'); return; }
    if (type === 'pic') { pickImage().then(function (url) { addRecord(c, { id: newId(), type: 'pic', src: url, cap: 'Type a caption' }); }); return; }
    var d = TPL[type], id = newId(); if (d.bw || d.bh) { var r = blk(id); if (d.bw) r.bw = d.bw; if (d.bh) r.bh = d.bh; }
    addRecord(c, { id: id, type: 'panel', cls: d.cls, html: d.html });
  }
  function boxTarget() { var b = selBlock(); return b && !figTarget(b) ? b : null; }
  function setFx(patch, done) {
    var b = selBlock(); if (!b) return; var r = blk(b.getAttribute('data-kb'));
    Object.keys(patch).forEach(function (x) { if (patch[x] === null) delete r[x]; else r[x] = patch[x]; });
    if (r.op === 1) delete r.op; applyBlock(b, r); if (done !== false) { commit(); updateBar(); } place();
  }
  function syncFx() {
    var b = selBlock(), g = q('#gFx'); if (!g) return; g.hidden = !b; if (!b) return;
    var r = E.block[b.getAttribute('data-kb')] || {}, cs = getComputedStyle(b);
    q('#edFill').value = rgbToHex(r.bg && r.bg !== 'transparent' ? r.bg : cs.backgroundColor); q('#edNoFill').classList.toggle('ed-primary', r.bg === 'transparent');
    q('#edBdc').value = rgbToHex(r.bd || cs.borderTopColor); q('#edBdw').value = String(r.bdw !== undefined ? r.bdw : (parseFloat(cs.borderTopWidth) || 0) ? Math.round(parseFloat(cs.borderTopWidth)) : 0);
    var op = r.op !== undefined ? r.op : 1; q('#edOp').value = Math.round(op * 100); q('#edOpV').textContent = Math.round(op * 100) + '%';
  }
  var presenting = false, wasEditing = false;
  function present(on) {
    if (on === presenting) return; presenting = on; document.body.classList.toggle('ed-present', on);
    if (on) {
      wasEditing = editing; deselect(); undecorate(document.body); document.body.style.paddingBottom = '';
      toast('Press Esc to leave Present mode'); try { var p = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (p && p.catch) p.catch(function () {}); } catch (x) {}
    } else {
      if (document.fullscreenElement && document.exitFullscreen) { try { document.exitFullscreen(); } catch (x) {} }
      if (wasEditing) { decorate(document.body); mode(); }
    }
  }
  document.addEventListener('keydown', function (e) { if (presenting && e.key === 'Escape') present(false); });
  document.addEventListener('fullscreenchange', function () { if (!document.fullscreenElement && presenting) present(false); });
  function clearAdded() {
    var added = qa('[data-added]'); if (!added.length) { toast('Nothing has been added to this page yet.'); return; }
    if (!window.confirm('Remove the ' + added.length + (added.length === 1 ? ' item' : ' items') + ' you added to this page? You can press Undo straight after.')) return;
    deselect(); var cs = qa('[data-kc]');
    added.forEach(function (b) { delete E.block[b.getAttribute('data-kb')]; b.remove(); });
    cs.forEach(function (c) { var ck = c.getAttribute('data-kc'); if (E.add[ck]) { var ids = E.add[ck].map(function (r) { return r.id; }); delete E.add[ck]; if (E.order[ck]) E.order[ck] = E.order[ck].filter(function (x) { return ids.indexOf(x) < 0; }); if (!E.order[ck].length) delete E.order[ck]; } });
    commit(); toast('Cleared. Press Undo to bring them back.');
  }
  function downloadLesson() {
    deselect(); var v = ['#viewLesson', '#viewFolio', '#viewHome'].map(function (s) { return q(s); }).filter(function (n) { return n && !n.hidden; })[0]; if (!v) { toast('Open a page first.'); return; }
    var c = v.cloneNode(true);
    qa('.ed-hidden', c).forEach(function (n) { n.remove(); });
    [c].concat(qa('*', c)).forEach(function (n) { ['contenteditable', 'spellcheck', 'draggable', 'data-kt', 'data-kb', 'data-kc', 'data-added', 'data-aid'].forEach(function (a) { n.removeAttribute(a); }); if (n.classList) n.classList.remove('ed-sel', 'ed-dragging'); });
    c.hidden = false; var title = ((q('h1', v) || {}).textContent || document.title || 'Lesson').trim(), css = qa('style').map(function (s) { return s.textContent; }).join('\n'), fonts = qa('link[rel="stylesheet"]').map(function (l) { return l.outerHTML; }).join('\n');
    var html = '<!DOCTYPE html>\n<html lang="en" data-theme="' + (document.documentElement.getAttribute('data-theme') || 'light') + '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + title.replace(/</g, '&lt;') + '</title>' + fonts + '<style>' + css + '</style></head><body><main class="wrap">' + c.outerHTML + '<p class="sub" style="text-align:center;margin-top:24px">A stand-alone copy of this lesson. Interactive activities only work on the website.</p></main></body></html>';
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' })); a.download = title.replace(/[\\/:*?"<>|]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 60) + '.html'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
    toast('Saved “' + a.download + '”.');
  }

  /* ---------- free positioning ---------- */
  function parseTr(s) { var m = /translate\(\s*(-?[\d.]+)px\s*,\s*(-?[\d.]+)px\s*\)/.exec(s || ''); return m ? { x: +m[1], y: +m[2] } : { x: 0, y: 0 }; }
  function freeTarget() { if (!editing || !sel || !document.body.contains(sel)) return null; return sel.hasAttribute('data-kt') ? sel : selBlock(); }
  function saveFree(t) {
    var p = parseTr(t.style.transform); if (!p.x && !p.y) { t.style.transform = ''; t.removeAttribute('data-kfree'); }
    if (t.hasAttribute('data-kt')) persistText(t);
    else { var k = t.getAttribute('data-kb'), r = blk(k), tr = t.style.transform; if (tr) r.tr = tr; else delete r.tr; }
    commit(); updateBar(); place();
  }
  function startFree(e) {
    var t = freeTarget(); if (!t) return; e.preventDefault();
    var sx = e.clientX, sy = e.clientY, b0 = parseTr(t.style.transform), moved = false;
    function mv(ev) { var x = Math.round(b0.x + ev.clientX - sx), y = Math.round(b0.y + ev.clientY - sy); t.style.transform = 'translate(' + x + 'px,' + y + 'px)'; t.setAttribute('data-kfree', '1'); moved = true; place(); }
    function up() { document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up); if (moved) saveFree(t); }
    document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
  }

  function place() {
    var ov = q('#edOv'); if (!ov) return;
    var b = editing ? selBlock() : null;
    if (!b || !document.body.contains(b)) { ov.hidden = true; return; }
    var r = b.getBoundingClientRect();
    ov.hidden = false; ov.style.left = (r.left + window.scrollX) + 'px'; ov.style.top = (r.top + window.scrollY) + 'px'; ov.style.width = r.width + 'px'; ov.style.height = r.height + 'px';
    q('#edResize').hidden = !(isFig() || boxTarget());
    var ft = freeTarget(), fh = q('#edFree'), fr = q('#edFreeReset'); if (fh) fh.textContent = ft && ft.hasAttribute('data-kt') ? '✥ Free (text)' : '✥ Free (box)'; if (fr) fr.hidden = !(ft && ft.hasAttribute('data-kfree'));
  }
  function syncPage() {
    var s = q('#edPage'); if (!s) return;
    var h = location.hash.replace('#', ''); var v = h.indexOf('folio') === 0 ? '#folio' : (h.indexOf('unit/') === 0 ? '#' + h : '#unit');
    s.value = v;
  }
  function mode() {
    document.body.classList.toggle('ed-editing', editing); document.body.classList.toggle('ed-teacher', teacher);
    if (!teacher) return;
    build(); q('#edBar').hidden = !editing; q('#edPrev').hidden = editing; if (!editing) { var ov = q('#edOv'); ov.hidden = true; }
    document.body.style.paddingBottom = editing ? (q('#edBar').offsetHeight + 24) + 'px' : '';
    if (editing) status();
  }

  /* ---------- saving ---------- */
  function download() {
    var txt = '/* Page edits. Upload this file next to the page (replace the old ' + EDITS_FILE + '), then commit. */\nwindow.' + EDITS_VAR + ' = ' + JSON.stringify(pruned(), null, 1) + ';\n';
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/javascript' })); a.download = EDITS_FILE; document.body.appendChild(a); a.click(); a.remove();
    toast('Downloaded ' + EDITS_FILE + '. Now upload it to GitHub next to the page (replace the old one) and commit.');
  }
  function exit() {
    try { sessionStorage.removeItem(FLAG); sessionStorage.removeItem(EDIT_FLAG); } catch (e) {}
    if (changedFromPublished() && !window.confirm('You have changes that are not published. They stay saved as a draft in this browser. Exit editing?')) { try { sessionStorage.setItem(FLAG, '1'); sessionStorage.setItem(EDIT_FLAG, editing ? '1' : '0'); } catch (e) {} return; }
    location.reload();
  }
  function login() {
    var p = window.prompt('Teacher password');
    if (p === null) return;
    if (p !== PASSWORD) { window.alert('That password is not right.'); return; }
    try { sessionStorage.setItem(FLAG, '1'); sessionStorage.setItem(EDIT_FLAG, '1'); } catch (e) {}
    location.reload();
  }

  function ready() {
    var s = q('#teachLink'); if (s) s.addEventListener('click', function (e) { e.preventDefault(); login(); });
    if (!teacher) return;
    build();
    var sel = q('#edPage'); var opts = ['<option value="#unit">Unit home</option>'];
    (window.CONCEPTS || []).forEach(function (c) { opts.push('<option value="#unit/' + c.id + '">' + c.title.replace(/</g, '&lt;') + '</option>'); });
    if (!CFG.noFolio) opts.push('<option value="#folio">My Folio (text only)</option>'); sel.innerHTML = opts.join('');
    syncPage(); mode(); status();
  }

  window.KCCEdit = { after: after, focus: focusView, ready: ready, editing: function () { return editing; }, isTeacher: function () { return teacher; },
    _t: { get E() { return E; }, set E(v) { E = v; }, tagAll: tagAll, applyAll: applyAll, clean: clean, reorder: reorder, select: select, selBlock: selBlock, moveBlock: moveBlock, toggleDelete: toggleDelete, setSpan: setSpan,
      setCols: setCols, setCrop: setCrop, curCrop: curCrop, applyBlock: applyBlock, handleDrop: handleDrop, setPicture: setPicture, pruned: pruned, toggleCropMode: toggleCropMode, patchStyle: patchStyle, bumpSize: bumpSize, addTo: addTo, undo: undo, redoIt: redoIt, download: download, figWidthBy: figWidthBy, figAlign: figAlign, persistText: persistText,
      hist: function () { return hist.length; }, commit: commit, selectParent: selectParent, get editing() { return editing; } } };
})();
