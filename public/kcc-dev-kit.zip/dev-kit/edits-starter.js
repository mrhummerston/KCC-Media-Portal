/* A blank edits file for a new page.
   1. Copy this file and rename it to match the page, e.g. year9-documentary-edits.js
   2. Change PAGE_EDITS below to the variable name you put in window.KCC_EDIT_CFG.editsVar (e.g. Y9DOC_EDITS)
   3. After editing in teacher mode, press "Save my changes", then upload the downloaded file over this one in GitHub. */
window.PAGE_EDITS = {"v":1,"text":{},"style":{},"block":{},"order":{},"hide":{},"cols":{},"add":{},"global":{}};
